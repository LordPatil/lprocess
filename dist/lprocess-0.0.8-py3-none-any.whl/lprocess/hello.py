def hello():
  print("Hello from a function") 
