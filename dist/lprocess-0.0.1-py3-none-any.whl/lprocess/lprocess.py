def hello():
	print("Hello")
